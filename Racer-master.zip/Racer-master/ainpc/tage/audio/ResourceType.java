package tage.audio;

/**
 * 
 * Modified from the SAGE Audio package for the RAGE game engine by Juan E. Ruiz.
 *
 */

public enum ResourceType {
	RESOURCE_NULL, RESOURCE_AUDIO
}
